This is Reminder Application from which we create , Update, View the Reminders.

It is the Mavenized project.

Setup Environment for this project:

	a. Java 1.8
	b. Servlet API 4.0.1 and JSP
	c. Eclispe IDE

1. For building command is : mvn clean install

2. To run on tomcat : -
		
		
		a. With embedded Tomcat 7 : tomcat7:run
		
		b. With External Server just right click on project and go to run as option and click on "Run on server"
		
